/*
   В примере демонстрируется
   асинхронное получение некоторых данных,
   которые асинхронно проверяются на тип данных string
   и выводятся на экран.
   
   Асинхронность реализована при помощи
   async функций.
*/

"use strict";

function getDataAsync() {
   return new Promise((resolve, reject) => {
      console.log("Получаем данные ...");
      setTimeout( // Имитация получения данных
         () => {
            let data = "Hello world!";
            console.log("Данные получены");
            resolve(data);
         },
         3000
      );
   });
}

function isStringAsync(value) {
   return new Promise((resolve, reject) => {
      console.log("Проверяем данные ...");
      setTimeout( // Имитация проверки
         () => {
            let result;
            if (typeof value === "string") {
               result = true;
            } else {
               result = false;
            }
            console.log("Данные проверены");
            resolve(result);
         },
         3000
      );
   });
}

async function start() {
   let data = await getDataAsync(); // Получение данных
   let isString = await isStringAsync(data); // Проверка данных
   console.log(`Получены данные ${isString ? "строчного" : "не строчного"} типа: ${data}`); // Вывод на экран
}

start();
setTimeout(
   start,
   2000
);