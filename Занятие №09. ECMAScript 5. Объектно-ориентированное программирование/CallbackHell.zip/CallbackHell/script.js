"use strict";

function step1(elem, nextStep) {
   setTimeout(function () {
      elem.style.width = "200px";
      nextStep();
   }, 1000);
}

function step2(elem, nextStep) {
   setTimeout(function () {
      elem.style.height = "200px";
      nextStep();
   }, 1000);
}

function step3(elem, nextStep) {
   setTimeout(function () {
      elem.style.width = "100px";
      nextStep();
   }, 1000);
}

function step4(elem) {
   setTimeout(function () {
      elem.style.height = "100px";
   }, 1000);
}

var div = document.getElementById("animationDiv");
var btn = document.getElementById("animationButton");

btn.onclick = function () {
   step1(
      div,
      function () {
         step2(
            div,
            function () {
               step3(
                  div,
                  function () {
                     step4(div);
                  }
               );
            }
         );
      }
   );
}