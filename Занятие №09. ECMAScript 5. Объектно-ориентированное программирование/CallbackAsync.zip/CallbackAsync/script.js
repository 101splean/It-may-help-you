/*
   В примере демонстрируется
   асинхронное получение некоторых данных,
   которые асинхронно проверяются на тип данных string
   и выводятся на экран.
   
   Асинхронность реализована при помощи
   методов обратного вызова (callback).
*/

"use strict";

function getDataAsync(callback) {
   console.log("Получаем данные ...");
   setTimeout( // Имитация получения данных
      function () {
         var data = "Hello world!";
         console.log("Данные получены");
         callback(data);
      },
      3000
   );
}

function isStringAsync(value, callback) {
   console.log("Проверяем данные ...");
   setTimeout( // Имитация проверки
      function () {
         var result;
         if (typeof value === "string") {
            result = true;
         } else {
            result = false;
         }
         console.log("Данные проверены");
         callback(result);
      },
      3000
   );
}

function start() {
   getDataAsync( // Получение данных
      function (dataRes) {
         isStringAsync( // Проверка данных
            dataRes,
            function (isStringRes) { // Вывод на экран
               var res = "Получены данные ";
               res += isStringRes ? "строчного" : "не строчного";
               res += " типа: " + dataRes;
               console.log(res);
            }
         );
      }
   );
}

start();
setTimeout(
   start,
   2000
);