/*
   В примере демонстрируется
   асинхронное получение некоторых данных,
   которые асинхронно проверяются на тип данных string
   и выводятся на экран.
   
   Асинхронность реализована при помощи
   Promise и генераторов.
*/

"use strict";

function getDataAsync() {
   return new Promise((resolve, reject) => {
      console.log("Получаем данные ...");
      setTimeout( // Имитация получения данных
         () => {
            let data = "Hello world!";
            console.log("Данные получены");
            resolve(data);
         },
         3000
      );
   });
}

function isStringAsync(value) {
   return new Promise((resolve, reject) => {
      console.log("Проверяем данные ...");
      setTimeout( // Имитация проверки
         () => {
            let result;
            if (typeof value === "string") {
               result = true;
            } else {
               result = false;
            }
            console.log("Данные проверены");
            resolve(result);
         },
         3000
      );
   });
}

function* promiseGenerator() { // Генератор, который yield'ит промисы
   let data = yield getDataAsync(); // Получение данных
   let isString = yield isStringAsync(data); // Проверка данных
   console.log(`Получены данные ${isString ? "строчного" : "не строчного"} типа: ${data}`); // Вывод на экран
}

function start() { // Функция, которая запускает генератор
   let pg = promiseGenerator();
   pg.next().value.then(
      (data) => pg.next(data).value.then(
         (isString) => pg.next(isString)
      )
   );
}

function execute(generator, yieldValue) { // Универсальная функция, которая может работать с любым генератором, который yield'ит промисы
   let next = generator.next(yieldValue);
   if (!next.done) {
      next.value.then(
         result => execute(generator, result),
         err => generator.throw(err)
      );
   }
}

start();
setTimeout(
   execute(promiseGenerator()),
   2000
);